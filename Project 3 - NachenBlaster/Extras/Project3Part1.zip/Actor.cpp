#include "Actor.h"
#include "StudentWorld.h"

bool Actor::getIsDead() const
{
	return isDead;
}

void Actor::setIsDead(bool in)
{
	isDead = in;
}

int Actor::getID()
{
	return id;
}

void Star::doSomething()
{
	double curx = getX();
	double cury = getY();
	moveTo(curx - 1, cury);
	if (getX() <= -1)
	{
		setIsDead(true);
	}
}

void NachenBlaster::doSomething()
{
	if (getIsDead() == true)
	{
		return;
	}

	int ch;
	if (getWorld()->getKey(ch))
	{
		switch (ch)
		{
		case 's':
		case KEY_PRESS_DOWN:
			if(getY() - 6 >= 0)
				moveTo(getX(), getY() - 6);
			break;
		case 'a':
		case KEY_PRESS_LEFT:
			if(getX() - 6 >= 0)
				moveTo(getX() - 6, getY());
			break;
		case 'd':
		case KEY_PRESS_RIGHT:
			if(getX() + 6 <= VIEW_WIDTH)
				moveTo(getX() + 6, getY());
			break;
		case 'w':
		case KEY_PRESS_UP:
			if(getY() + 6 <= VIEW_HEIGHT)
				moveTo(getX(), getY() + 6);
			break;
		case KEY_PRESS_SPACE:
			getWorld()->addActor(IID_CABBAGE, getX() + 12, getY(), 0, 0.5, 1, getWorld());
			getWorld()->playSound(SOUND_PLAYER_SHOOT);
			break;
		default:
			break;
		}
	}

	if (hp <= 0)
	{
		setIsDead(true);
	}
}

void Cabbage::doSomething()
{
	if (getIsDead() == false)
	{
		if (getX() >= VIEW_WIDTH)
		{
			setIsDead(true);
		}
		else		//check if collided
		{
			moveTo(getX() + 8, getY());
			setDirection(getDirection() + 20);
			//check again if collided
		}
	}
	else 
	{
		return;
	}
}

StudentWorld *Actor::getWorld()
{
	return world;
}
// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp
