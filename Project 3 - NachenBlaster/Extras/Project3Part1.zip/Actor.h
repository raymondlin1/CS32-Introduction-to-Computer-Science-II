#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, int startDirection, double size, int depth, StudentWorld *p)
		:GraphObject(imageID, startX, startY, startDirection, size, depth)
	{
		isDead = false;
		world = p;
		id = imageID;
	}

	virtual void doSomething() = 0;
	bool getIsDead() const;
	void setIsDead(bool in);
	StudentWorld *getWorld();
	int getID();
private:
	int id;
	bool isDead;
	StudentWorld *world;
};

class Star : public Actor
{
public:
	Star(int startX, int startY, double size, StudentWorld* p)
		:Actor(IID_STAR, startX, startY, 0, size, 3, p)
	{

	}

	virtual void doSomething();
};

class Projectile : public Actor
{
public:
	Projectile(int id, int startX, int startY, int dir, double size, int depth, StudentWorld* p)
		:Actor(id, startX, startY, dir, size, depth, p)
	{

	}
	virtual void doSomething() = 0;
};

class Cabbage :public Projectile
{
public:
	Cabbage(int startX, int startY, StudentWorld* p)
		:Projectile (IID_CABBAGE, startX, startY, 0, 0.5, 1, p)
	{

	}
	virtual void doSomething();
};

class NachenBlaster : public Actor
{
public:
	NachenBlaster(StudentWorld* p)
		:Actor(IID_NACHENBLASTER, 0, 128, 0, 1.0, 0, p)
	{
		hp = 50;
		cp = 30;
	}
	virtual void doSomething();
private:
	int hp;
	int cp;
};

#endif // ACTOR_H_
