#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Actor.h"
#include <vector>
#include <string>
using namespace std;

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetDir);
    virtual int init();
    virtual int move();
    virtual void cleanUp();

	virtual ~StudentWorld();
	void addActor(int imageID, int startX, int startY, int startDirection, double size, int depth, StudentWorld *p);
private:
	vector<Actor *> actors;
	vector<NachenBlaster *> nb;
	int numDestroyed;
};

#endif // STUDENTWORLD_H_