#include "StudentWorld.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

StudentWorld::StudentWorld(string assetDir)
: GameWorld(assetDir)
{
	numDestroyed = 0;
}

int StudentWorld::init()
{
	nb.push_back(new NachenBlaster(this));
	numDestroyed = 0;
	for (int i = 0; i < 30; i++)
	{
		double size = randInt(5, 50);
		actors.push_back(new Star(randInt(0, VIEW_WIDTH - 1), randInt(0, VIEW_HEIGHT - 1), size * 0.01, this));
	}
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
	vector<NachenBlaster*>::iterator nachenPointer = nb.begin();
	(*nachenPointer)->doSomething();
	vector<Actor *>::iterator it = actors.begin();
	while (it != actors.end())
	{
		(*it)->doSomething();
		if ((*it)->getIsDead() == true)
		{
			if ((*it)->getID() == IID_STAR)
			{
				double size = randInt(5, 50);
				actors.push_back(new Star(VIEW_WIDTH - 1, randInt(0, VIEW_HEIGHT - 1), size * 0.01, this));
			}
			delete (*it);
			it = actors.erase(it);
			
		}
		else {
			it++;
		}
	}

    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	vector<Actor *>::iterator it = actors.begin();
	while (it != actors.end())
	{
		delete (*it);
		it = actors.erase(it);
	}
}

void StudentWorld::addActor(int imageID, int startX, int startY, int startDirection, double size, int depth, StudentWorld *p)
{
	switch (imageID)
	{
	case IID_CABBAGE:
		actors.push_back(new Cabbage(startX, startY, p));
		break;
	case IID_EXPLOSION:
		break;
	case IID_LIFE_GOODIE:
		break;
	case IID_REPAIR_GOODIE:
		break;
	case IID_SMALLGON:
		break;
	case IID_SMOREGON:
		break;
	case IID_SNAGGLEGON:
		break;
	case IID_STAR:
		break;
	case IID_TORPEDO:
		break;
	case IID_TORPEDO_GOODIE:
		break;
	case IID_TURNIP:
		break;
	default:
		break;
	}
}

StudentWorld::~StudentWorld()
{
	if (actors.size() > 0)
	{
		vector<Actor *>::iterator it = actors.begin();
		while (it != actors.end())
		{
			delete (*it);
			it = actors.erase(it);
		}
	}

	if (nb.size() == 1)
	{
		vector<NachenBlaster *>::iterator ni = nb.begin();
		delete (*ni);
		ni = nb.erase(ni);
	}
}